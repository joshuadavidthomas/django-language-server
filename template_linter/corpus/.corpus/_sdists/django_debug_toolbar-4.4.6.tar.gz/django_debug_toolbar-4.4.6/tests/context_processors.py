def broken(request):
    _read = request.non_existing_attribute
