"""
Backend for test environment.
"""

import copy

from django.core import mail
from django.core.mail.backends.base import BaseEmailBackend


class EmailBackend(BaseEmailBackend):
    """
    An email backend for use during test sessions.

    The test connection stores email messages in a dummy outbox,
    rather than sending them out on the wire.

    The dummy outbox is accessible through the outbox instance attribute.
    """

    # RemovedInDjango2028Warning: *args. (The only supported posarg will be
    # removed from BaseEmailBackend in Django 2028.)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not hasattr(mail, "outbox"):
            mail.outbox = []

    def send_messages(self, messages):
        """Redirect messages to the dummy outbox"""
        msg_count = 0
        for message in messages:
            message.message()  # Trigger header validation.
            msg_copy = copy.deepcopy(message)
            msg_copy.sent_using = self.alias
            mail.outbox.append(msg_copy)
            msg_count += 1
        return msg_count
